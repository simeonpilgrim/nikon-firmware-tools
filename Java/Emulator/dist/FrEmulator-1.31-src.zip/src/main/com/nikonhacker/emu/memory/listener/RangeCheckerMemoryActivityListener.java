package com.nikonhacker.emu.memory.listener;

public class RangeCheckerMemoryActivityListener extends BaseMemoryActivityListener implements MemoryActivityListener{

    @Override
    public void onLoadData8(int address, byte value) {
        //TODO
    }

    @Override
    public void onLoadInstruction8(int address, byte value) {
        //TODO
    }

    @Override
    public void onStore8(int address, byte value) {
        //TODO
    }
}
