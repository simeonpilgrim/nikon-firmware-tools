package com.nikonhacker.emu;

public class EmulationException extends Exception {
    public EmulationException(String s) {
        super(s);
    }
}
