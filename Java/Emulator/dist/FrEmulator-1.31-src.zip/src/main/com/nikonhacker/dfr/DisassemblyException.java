package com.nikonhacker.dfr;

public class DisassemblyException extends Exception {
    public DisassemblyException(String msg) {
        super(msg);
    }
}
