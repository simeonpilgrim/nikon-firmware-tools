package com.nikonhacker.gui;

import com.mxgraph.canvas.mxICanvas;
import com.mxgraph.canvas.mxSvgCanvas;
import com.mxgraph.layout.hierarchical.mxHierarchicalLayout;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.util.mxCellRenderer;
import com.mxgraph.util.mxUtils;
import com.mxgraph.view.mxGraph;
import com.nikonhacker.Format;
import com.nikonhacker.dfr.Function;
import com.nikonhacker.dfr.Jump;

import javax.swing.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CallGraph extends JFrame
{

    private Map<Integer, Function> functions = new HashMap<Integer, Function>();

    public CallGraph() throws IOException {
		super("Hello, World!");

        showGraph();
    }

    public void showGraph() throws IOException {
		mxGraph graph = new mxGraph();
		Object parent = graph.getDefaultParent();

		graph.getModel().beginUpdate();

        try
		{
            Map<Integer,Object> functionObjects = new HashMap<Integer, Object>();
            // Add all functions as nodes
            for (Function function : functions.values()) {
                Object vertex = graph.insertVertex(parent, null, function.getName() + "\n0x" + Format.asHex(function.getAddress(), 8), 0, 0, 80, 30, "defaultVertex;fillColor=" + function.getColor());
                functionObjects.put(function.getAddress(), vertex);
            }
            // Add all calls as edges
            for (Function function : functions.values()) {
                for (Jump call : function.getCalls()) {
                    Object edge = graph.insertEdge(parent, null, "", functionObjects.get(function.getAddress()), functionObjects.get(call.getTarget()));
                }
            }


//            List parents = new ArrayList();
//            List children = new ArrayList();
//            List gchildren = new ArrayList();
//            Object main = graph.insertVertex(parent, null, "main", 0, 0, 80, 15);
//            for (int i = 0; i < 5; i++) {
//                Object p = graph.insertVertex(parent, null, "parent_" + i, 0, 0, 80, 15);
//                parents.add(p);
//                graph.insertEdge(parent, null, "", main, p);
//                for (int j = 0; j < 5; j++) {
//                    Object c = graph.insertVertex(parent, null, "child_" + i + "." + j, 0, 0, 80, 15);
//                    children.add(c);
//                    graph.insertEdge(parent, null, "", p, c);
//                    for (int k = 0; k < 5; k++) {
//                        Object gc = graph.insertVertex(parent, null, "gchild_" + i + "." + j + "." + k, 0, 0, 80, 15);
//                        gchildren.add(gc);
//                        graph.insertEdge(parent, null, "", c, gc);
//                    }
//                }
//            }
//            graph.insertEdge(parent, null, "", parents.get(3), children.get(12));
//            graph.insertEdge(parent, null, "", parents.get(2), gchildren.get(94));
		}
		finally
		{
			graph.getModel().endUpdate();
		}
        Object cell = graph.getDefaultParent();

        // Layout
        graph.getModel().beginUpdate();
        mxHierarchicalLayout layout = new mxHierarchicalLayout(graph, SwingConstants.WEST);
//        layout.setIntraCellSpacing(layout.getIntraCellSpacing() * 0); // between elements at the same level
        layout.setInterRankCellSpacing(200);
        try {
            layout.execute(cell);
        }
        finally {
            graph.getModel().endUpdate();
        }

        // Save as SVG
        mxSvgCanvas canvas = (mxSvgCanvas) mxCellRenderer.drawCells(graph, null, 1, null,
                new mxCellRenderer.CanvasFactory() {
                    public mxICanvas createCanvas(int width, int height) {
                        mxSvgCanvas c = new mxSvgCanvas(mxUtils.createSvgDocument(width, height));
                        c.setEmbedded(true);
                        return c;
                    }
                });
        mxUtils.writeFile(mxUtils.getXml(canvas.getDocument()), "d:\\graphtest.svg");


		mxGraphComponent graphComponent = new mxGraphComponent(graph);
		getContentPane().add(graphComponent);
	}

    public CallGraph(Map<Integer, Function> functions) throws IOException {
        this.functions= functions;

        showGraph();
    }

    public static void main(String[] args) throws IOException {
		CallGraph frame = new CallGraph();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 320);
		frame.setVisible(true);
	}

}
