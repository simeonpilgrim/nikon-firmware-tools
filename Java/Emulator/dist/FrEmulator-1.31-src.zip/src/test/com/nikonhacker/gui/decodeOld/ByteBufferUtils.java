package com.nikonhacker.gui.decodeOld;

import java.nio.ByteBuffer;
import java.io.UnsupportedEncodingException;

public class ByteBufferUtils {
    static int getUInt8(ByteBuffer buffer, int offset) {
        return buffer.get(offset) & 0xFF;
    }

    static int getUInt16(ByteBuffer buffer, int offset, boolean littleEndian) {
        final int v0 = buffer.get(offset) & 0xFF;
        final int v1 = buffer.get(offset + 1) & 0xFF;
        if (littleEndian) {
            return ((v1 << 8) | v0);
        } else {
            return ((v0 << 8) | v1);
        }
    }

    static int getUInt24(ByteBuffer buffer, int offset, boolean littleEndian) {
        final int v0 = buffer.get(offset) & 0xFF;
        final int v1 = buffer.get(offset + 1) & 0xFF;
        final int v2 = buffer.get(offset + 2) & 0xFF;
        if (littleEndian) {
            return ((v2 << 16) | (v1 << 8) | v0);
        } else {
            return ((v0 << 16) | (v1 << 8) | v2);
        }
    }

    static long getUInt32(ByteBuffer buffer, int offset, boolean littleEndian) {
        final long v0 = buffer.get(offset) & 0xFF;
        final long v1 = buffer.get(offset + 1) & 0xFF;
        final long v2 = buffer.get(offset + 2) & 0xFF;
        final long v3 = buffer.get(offset + 3) & 0xFF;
        if (littleEndian) {
            return ((v3 << 24) | (v2 << 16) | (v1 << 8) | v0);
        } else {
            return ((v0 << 24) | (v1 << 16) | (v2 << 8) | v3);
        }
    }

    public static String getString(ByteBuffer buffer, int offset, int length) {
        StringBuilder b = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int v = buffer.get(offset + i);
            b.append((char) v);
        }
        return b.toString();
    }

    public static String getNullTerminatedString(ByteBuffer buffer, int offset, int length) {
        StringBuilder b = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int v = getUInt8(buffer, offset + i);
            if (v == 0) {
                break;
            }
            b.append((char) v);
        }
        return b.toString();
    }

    public static String getUTF8String(ByteBuffer buffer, int offset, int length) {
        byte[] array = new byte[length];
        for (int i = 0; i < length; i++) {
            array[i] = buffer.get(offset + i);
        }
        try {
            return new String(array, 0, length, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return "?";
        }
    }
}
